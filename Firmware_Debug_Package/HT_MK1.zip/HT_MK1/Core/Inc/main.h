/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.h
  * @brief          : Header for main.c file.
  *                   This file contains the common defines of the application.
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2026 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */

/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __MAIN_H
#define __MAIN_H

#ifdef __cplusplus
extern "C" {
#endif

/* Includes ------------------------------------------------------------------*/
#include "stm32g4xx_hal.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */

/* USER CODE END Includes */

/* Exported types ------------------------------------------------------------*/
/* USER CODE BEGIN ET */

/* USER CODE END ET */

/* Exported constants --------------------------------------------------------*/
/* USER CODE BEGIN EC */

/* USER CODE END EC */

/* Exported macro ------------------------------------------------------------*/
/* USER CODE BEGIN EM */

/* USER CODE END EM */

/* Exported functions prototypes ---------------------------------------------*/
void Error_Handler(void);

/* USER CODE BEGIN EFP */

/* USER CODE END EFP */

/* Private defines -----------------------------------------------------------*/
#define HV_CARD_DT_1_0_Pin GPIO_PIN_13
#define HV_CARD_DT_1_0_GPIO_Port GPIOC
#define HV_CARD_DT_1_1_Pin GPIO_PIN_14
#define HV_CARD_DT_1_1_GPIO_Port GPIOC
#define HV_CARD_DT_2_1_Pin GPIO_PIN_0
#define HV_CARD_DT_2_1_GPIO_Port GPIOC
#define I2C2_CS_Pin GPIO_PIN_2
#define I2C2_CS_GPIO_Port GPIOC
#define I2C3_CS_Pin GPIO_PIN_3
#define I2C3_CS_GPIO_Port GPIOC
#define HV_CARD_EN1_Pin GPIO_PIN_5
#define HV_CARD_EN1_GPIO_Port GPIOC
#define SPI3_CS_Pin GPIO_PIN_1
#define SPI3_CS_GPIO_Port GPIOB
#define SPI3_CSB2_Pin GPIO_PIN_2
#define SPI3_CSB2_GPIO_Port GPIOB
#define GPIO2_ISO_Pin GPIO_PIN_12
#define GPIO2_ISO_GPIO_Port GPIOB
#define HV_CARD_EN2_Pin GPIO_PIN_6
#define HV_CARD_EN2_GPIO_Port GPIOC
#define HV_CARD_EN4_Pin GPIO_PIN_9
#define HV_CARD_EN4_GPIO_Port GPIOA
#define HV_CARD_EN3_Pin GPIO_PIN_10
#define HV_CARD_EN3_GPIO_Port GPIOA
#define OPT0_CNTR_Pin GPIO_PIN_12
#define OPT0_CNTR_GPIO_Port GPIOC
#define HV_CARD_DT_2_0_Pin GPIO_PIN_2
#define HV_CARD_DT_2_0_GPIO_Port GPIOD
#define GPIO1_ISO_Pin GPIO_PIN_6
#define GPIO1_ISO_GPIO_Port GPIOB
#define GPIO0_ISO_Pin GPIO_PIN_7
#define GPIO0_ISO_GPIO_Port GPIOB
#define GPIO3_ISO_Pin GPIO_PIN_9
#define GPIO3_ISO_GPIO_Port GPIOB

/* USER CODE BEGIN Private defines */

/* USER CODE END Private defines */

#ifdef __cplusplus
}
#endif

#endif /* __MAIN_H */
