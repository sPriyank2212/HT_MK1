/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file    tasks.c
  * @brief   FreeRTOS task architecture implementation. See tasks.h.
  ******************************************************************************
  */
/* USER CODE END Header */

#include "app/tasks.h"
#include "app/log.h"
#include "app/proto.h"
#include "app/run_logic.h"
#include "bsp/board.h"
#include "test/continuity.h"
#include "test/kelvin.h"
#include "test/insulation.h"
#include "drivers/ds18b20.h"
#include "cmsis_os2.h"
#include <string.h>

/* Bench-only ADS1232 rig. Compiles to nothing unless HT_ENABLE_ADS1232=1. */
#include "drivers/ads1232.h"

/* ---- shared state -------------------------------------------------------- */
static osMessageQueueId_t s_cmdq;
static osMessageQueueId_t s_rxq;        /* console RX bytes, ISR -> tComms     */
static osMutexId_t        s_hwmtx;      /* serialises I2C/SPI bus access      */
static UART_HandleTypeDef *s_console;   /* USB-UART carrying the GUI protocol  */
static uint8_t            s_rx_byte;    /* landing slot for HAL_UART_Receive_IT */
static volatile uint8_t   s_fault;
static volatile uint8_t   s_hv_active;
static volatile uint32_t  s_hv_last_tick;   /* last time any code drove HV      */

/* ---- thread handles + attributes ----------------------------------------- */
static osThreadId_t s_safety, s_seq, s_comms, s_logger;

/* tComms sits ABOVE tSequencer deliberately (FW-07). It spends its life blocked
 * on the RX queue, so it costs nothing until a byte arrives; below the sequencer
 * it was never scheduled during a run, and >ABORT - which works by setting a
 * flag the run loops poll - could not be received at all. */
/* Stack sizes were doubled from the first bring-up values (256/512/256 words):
 * every thread formats printf-style text (nano newlib, floats via snprintf in
 * the log) and tSequencer also holds a BoardBusEntry_t array for BUS SCAN.
 * Stack-overflow checking is now ON (FreeRTOSConfig.h), but a smaller stack that
 * "passes" is no evidence it is big enough - measure with
 * uxTaskGetStackHighWaterMark() at bring-up before shrinking any of these. */
static const osThreadAttr_t s_attr_safety = { .name = "tSafety",    .priority = osPriorityHigh,        .stack_size = 512 * 4 };
static const osThreadAttr_t s_attr_seq    = { .name = "tSequencer", .priority = osPriorityNormal,      .stack_size = 1024 * 4 };
static const osThreadAttr_t s_attr_comms  = { .name = "tComms",     .priority = osPriorityAboveNormal, .stack_size = 512 * 4 };
static const osThreadAttr_t s_attr_logger = { .name = "tLogger",    .priority = osPriorityLow,         .stack_size = 256 * 4 };

#if (HT_ENABLE_ADS1232 != 0)
static osThreadId_t s_ads1232;
static const osThreadAttr_t s_attr_ads1232 = { .name = "tAds1232",  .priority = osPriorityBelowNormal, .stack_size = 384 * 4 };

/**
  * @brief  BENCH ONLY. Bring up the ADS1232 4-wire rig and log a reading a second.
  * @note   Not part of the product firmware - see Doc/ADS1232_bench_wiring.md.
  *         Runs standalone: it touches no card, no bus mutex and no matrix, so
  *         it cannot disturb the rest of the system.
  * @param  arg : [in] unused.
  * @retval Does not return.
  */
static void Ads1232BenchTask(void *arg)
{
  (void)arg;

  LOG_W("ADS", "BENCH BUILD - not for release");

  if (ADS1232_HwInit_Nucleo() != HAL_OK)
  {
    LOG_E("ADS", "hw init failed");
    for (;;) { osDelay(1000U); }
  }

  /* Diagnostics only speak up when something is wrong, so a healthy rig goes
   * straight to printing data. */
  ADS1232_BenchDiag();

  if (ADS1232_BenchSelfCheck() != HAL_OK)
  {
    ADS1232_BenchPinTest(3U);

    /* Do not demand a perfect link before showing data - reads retry
     * internally, so a marginal joint slows the rig rather than stopping it. */
    while (ADS1232_BenchLinkTest(20U) < 25U)
    {
      osDelay(1000U);
    }
    while (ADS1232_BenchSelfCheck() != HAL_OK)
    {
      osDelay(1000U);
    }
  }

  LOG_I("ADS", "Rref=%ld g=128", (long)ADS1232_BENCH_RREF_OHMS);

  for (;;)
  {
    ADS1232_BenchOnce();
    osDelay(1000U);
  }
}
#endif /* HT_ENABLE_ADS1232 */

/* ---- safety -------------------------------------------------------------- */

/**
  * @brief  Latch a global fault and log the reason.
  * @note   Sets the fault flag the safety task polls; stays latched until
  *         Safety_ClearFault(). Callable from any thread.
  * @param  reason : [in] short human-readable cause; NULL logs as "?".
  * @retval None
  */
void Safety_SignalFault(const char *reason)
{
  s_fault = 1U;
  LOG_E("SAFE", "fault: %s", (reason != NULL) ? reason : "?");
}

/**
  * @brief  Clear the latched fault so normal operation can resume.
  * @retval None
  */
void Safety_ClearFault(void) { s_fault = 0U; }

/**
  * @brief  Query whether the instrument is currently in a latched fault.
  * @retval int non-zero if a fault is latched, 0 otherwise.
  */
int  Safety_InFault(void)    { return (int)s_fault; }

/**
  * @brief  Force the whole instrument to a safe state.
  * @note   Disables HV and opens all relays on every HV board, then opens the
  *         matrix. Caller must already hold the hardware mutex.
  * @retval None
  */
static void force_safe_all(void)
{
  uint8_t i;
  for (i = 0U; i < (uint8_t)BOARD_HV_COUNT; i++)
  {
    (void)HvCard_HvEnable(&g_hv[i], 0U);
    (void)HvCard_OpenAllRelays(&g_hv[i]);
  }
  (void)MatrixCard_AllOff(&g_matrix);
}

/* Note that HV was just driven (or just made safe). The idle rail monitor stays
 * quiet for RAIL_MON_HOLDOFF_MS afterwards: the rail bleeds down passively
 * through the sense divider, and a monitor that fired during that bleed would
 * latch a fault on every healthy run. */
static void hv_activity(void) { s_hv_last_tick = osKernelGetTickCount(); }

/* ---- idle HV rail monitor ------------------------------------------------ */

/* While nothing is driving HV, the rail monitor of every fitted card must read
 * "off". A rail that is live with no test running means the DAC, the supply or
 * a chip-select is wrong - latch a fault and force everything safe. Rail level
 * at the ADC for RAIL_MON_LIVE_RAIL_V volts on the rail. Bring-up tunable. */
#define RAIL_MON_PERIOD_MS    250U
#define RAIL_MON_HOLDOFF_MS   5000U
#define RAIL_MON_LIVE_RAIL_V  50.0f

static void rail_monitor(void)
{
  uint8_t i;
  uint8_t live = 0U;

  if (Board_IsReady() == 0U) { return; }              /* cards not initialised */
  if (osMutexAcquire(s_hwmtx, 0U) != osOK) { return; } /* a run owns the hardware */
  for (i = 0U; i < (uint8_t)BOARD_HV_COUNT; i++)
  {
    uint16_t code = 0U;
    HvCard_Hold(&g_hv[i]);
    if (HvCard_ReadRailRaw(&g_hv[i], &code) == HAL_OK &&
        AD7476_CodeToVolts(code, g_hv[i].cfg.vref) >
            (RAIL_MON_LIVE_RAIL_V * INSULATION_HV_SENSE_RATIO))
    {
      live = 1U;
    }
    HvCard_Unhold(&g_hv[i]);
  }
  osMutexRelease(s_hwmtx);
  if (live != 0U)
  {
    Safety_SignalFault("HV rail live while idle");
  }
}

/* ---- independent watchdog ------------------------------------------------ */

/* IWDG on the LSI (~32 kHz): /32 prescaler -> ~1 kHz tick, reload 499 -> ~500 ms
 * timeout. Driven through the CMSIS registers directly: the HAL IWDG driver is
 * not part of this project's build. A reset re-runs Board_Init(), which leaves
 * the HV DAC at 0 V and every relay open, so a hung MCU can no longer hold the
 * last programmed HV level. */
#define WDG_PRESCALER_DIV32   3U
#define WDG_RELOAD_TICKS      499U

static void watchdog_start(void)
{
#ifdef DEBUG
  DBGMCU->APB1FZR1 |= DBGMCU_APB1FZR1_DBG_IWDG_STOP;   /* freeze while halted */
#endif
  /* Start FIRST. Writing 0xCCCC forces the LSI on; the PR/RLR update flags in
   * IWDG->SR are only cleared by the LSI domain, so with the LSI still off the
   * wait below would never end (the safety task, the highest priority, would
   * spin forever and starve comms and the logger). This is the order the ST HAL
   * uses. The wait is bounded so a dead LSI can never hang the thread. */
  uint32_t t0 = osKernelGetTickCount();
  IWDG->KR  = 0xCCCCU;                       /* start - cannot be stopped; LSI on */
  IWDG->KR  = 0x5555U;                       /* unlock PR/RLR */
  IWDG->PR  = WDG_PRESCALER_DIV32;
  IWDG->RLR = WDG_RELOAD_TICKS;
  while (IWDG->SR != 0U)                     /* wait for PVU/RVU/WVU to clear */
  {
    if ((osKernelGetTickCount() - t0) > 50U) { break; }
  }
  IWDG->KR  = 0xAAAAU;                       /* load the counter */
}

static inline void watchdog_refresh(void) { IWDG->KR = 0xAAAAU; }

/**
  * @brief  High-priority safety thread: enforce the safe state.
  * @note   Runs forever on a 10 ms tick. While a fault is latched it forces the
  *         instrument safe (under the bus mutex) and keeps it latched. When idle
  *         and no HV is active it re-asserts HV-disabled as a backstop. The IWDG
  *         is started here and refreshed every tick, so a hung MCU resets.
  * @param  arg : [in] unused FreeRTOS thread argument.
  * @retval None (does not return).
  */
static void SafetyTask(void *arg)
{
  uint32_t last_mon = 0U;
  (void)arg;
  LOG_I("SAFE", "task up");
  if ((RCC->CSR & RCC_CSR_IWDGRSTF) != 0U)
  {
    LOG_W("SAFE", "previous reset was the watchdog");
    RCC->CSR |= RCC_CSR_RMVF;
  }
  watchdog_start();
  for (;;)
  {
    if (s_fault)
    {
      /* Force safe under the bus mutex; keep latched until cleared. */
      if (osMutexAcquire(s_hwmtx, 50U) == osOK)
      {
        force_safe_all();
        osMutexRelease(s_hwmtx);
      }
    }
    else if (!s_hv_active)
    {
      /* Backstop: ensure HV outputs are disabled when idle (GPIO-only). */
      uint8_t i;
      uint32_t now = osKernelGetTickCount();
      for (i = 0U; i < (uint8_t)BOARD_HV_COUNT; i++)
      {
        (void)HvCard_HvEnable(&g_hv[i], 0U);
      }
      if ((now - last_mon) >= RAIL_MON_PERIOD_MS &&
          (now - s_hv_last_tick) >= RAIL_MON_HOLDOFF_MS)
      {
        last_mon = now;
        rail_monitor();
      }
    }
    watchdog_refresh();
    osDelay(10U);
  }
}

/* ---- sequencer ----------------------------------------------------------- */

static void run_continuity_all(uint8_t discover);
static void run_resistance_all(void);
static void run_insulation_all(void);
static void run_manual_sweep(uint16_t hi);

/**
  * @brief  Execute one test command under the hardware mutex.
  * @note   Skips execution (logs a warning) if a fault is latched. Serialises
  *         all bus access by holding s_hwmtx for the whole operation, dispatches
  *         on the command type, and logs the result. For insulation it brackets
  *         the run with s_hv_active so the safety task knows HV is expected up.
  * @param  c : [in] command to run; must be non-NULL.
  * @retval None
  */
static void run_command(const TestCmd_t *c)
{
  /* Checked before the fault gate: clearing the latch is the one thing that has
   * to work WHILE faulted, or the only recovery is a power cycle. */
  if (c->type == CMD_CLEAR_FAULT)
  {
    (void)osMutexAcquire(s_hwmtx, osWaitForever);
    force_safe_all();
    hv_activity();
    Safety_ClearFault();
    Proto_ClearArm();
    Proto_EvtHv(0);
    Proto_EvtSafe();
    Proto_EvtState("idle");
    osMutexRelease(s_hwmtx);
    LOG_I("SEQ", "fault cleared");
    return;
  }

  if (s_fault)
  {
    LOG_W("SEQ", "skip (fault)");
    /* A run command that never reports !DONE leaves the GUI waiting for ever,
     * and s_busy stays latched so every later run is refused EBUSY. Say the run
     * is over, and say why, before returning (FW-10). */
    switch (c->type)
    {
      case CMD_CONT_RUN:     Proto_EvtState("fault"); Proto_EvtDone("cont",  0U, 0U); break;
      case CMD_RES_RUN:      Proto_EvtState("fault"); Proto_EvtDone("res",   0U, 0U); break;
      case CMD_INSUL_RUN:    Proto_EvtState("fault"); Proto_EvtDone("insul", 0U, 0U); break;
      case CMD_MANUAL_SWEEP: Proto_EvtState("fault"); Proto_EvtDone("sweep", 0U, 0U); break;
      default: break;
    }
    return;
  }

  (void)osMutexAcquire(s_hwmtx, osWaitForever);
  switch (c->type)
  {
    case CMD_CONTINUITY:
    {
      ContinuityResult_t r;
      if (Continuity_TestPair(c->a, c->b, &r) == HAL_OK)
      {
        LOG_I("CONT", "%u-%u %dmV v=%d", c->a, c->b, (int)(r.volts * 1000.0f), (int)r.verdict);
        /* CMD_CONTINUITY is only ever reached via MANUAL PATH (proto.c) -
         * CONT RUN calls Continuity_TestPair directly in its own loop, never
         * through the command queue - so this event can't fire mid-scan. */
        Proto_EvtManual((int32_t)(r.volts * 1000.0f), r.code);
      }
      else { LOG_E("CONT", "%u-%u bus err", c->a, c->b); }
      break;
    }
    case CMD_KELVIN:
    {
      KelvinResult_t r;
      if (Kelvin_MeasurePair(c->a, c->b, &r) == HAL_OK)
      {
        LOG_I("KELV", "%u-%u %dmohm v=%d", c->a, c->b, (int)(r.resistance_ohm * 1000.0f), (int)r.verdict);
        /* CMD_KELVIN is only ever reached via CAL RUN (proto.c) - RES RUN
         * calls Kelvin_MeasurePair directly in its own loop, same reasoning
         * as CMD_CONTINUITY/MANUAL PATH above. */
        Proto_EvtCalResult((int32_t)(r.resistance_ohm * 1000.0f),
                           r.ratiometric, (r.verdict == TEST_PASS) ? 1U : 0U);
      }
      else { LOG_E("KELV", "%u-%u bus err", c->a, c->b); }
      break;
    }
    case CMD_INSULATION:
    {
      InsulationResult_t r;
      s_hv_active = 1U;
      LOG_I("INS", "b%u %u-%u vf=%d start", c->board, c->a, c->b, (int)(c->vfrac * 100.0f));
      if (c->a < 1U || c->a > HV_PINS_PER_SIDE || c->b < 1U || c->b > HV_PINS_PER_SIDE)
      {
        /* Pins are local to one HV card (1..64); never truncate into uint8_t. */
        LOG_E("INS", "b%u pins %u-%u outside 1..%u", c->board, c->a, c->b, HV_PINS_PER_SIDE);
        r.sense_volts = 0.0f;
        r.verdict = TEST_ERROR;
        r.hw_fault = INS_HW_NONE;
      }
      else
      {
        r.hw_fault = INS_HW_NONE;
        (void)Insulation_TestPair(c->board, (uint8_t)c->a, (uint8_t)c->b, c->vfrac, &r);
      }
      s_hv_active = 0U;
      hv_activity();
      if (r.hw_fault != INS_HW_NONE) { Safety_SignalFault("HV path fault during manual insulation test"); }
      LOG_I("INS", "b%u sense=%dmV v=%d", c->board, (int)(r.sense_volts * 1000.0f), (int)r.verdict);
      break;
    }
    case CMD_BUS_SCAN:
    {
      BoardBusEntry_t entries[BOARD_BUS_SCAN_MAX];
      uint8_t total = Board_ScanBus(entries, BOARD_BUS_SCAN_MAX);
      uint8_t i, ok_count = 0U, fault_count = 0U;
      Proto_EvtState("running");
      for (i = 0U; i < total; i++)
      {
        Proto_EvtBusLine(entries[i].name, entries[i].ok);
        if (entries[i].ok != 0U) { ok_count++; } else { fault_count++; }
      }
      Proto_EvtState("idle");
      Proto_EvtDone("bus", ok_count, fault_count);
      LOG_I("BUS", "scan: %u ok, %u fault", ok_count, fault_count);
      break;
    }
    case CMD_TEMP_READ:
    {
      float c;
      if (DS18B20_ReadTemperature(&g_ds18b20, &c) == HAL_OK)
      {
        int32_t deci_c = (int32_t)((c >= 0.0f) ? (c * 10.0f + 0.5f) : (c * 10.0f - 0.5f));
        Proto_EvtTemp(deci_c);
        LOG_I("TEMP", "%ld deci-C", (long)deci_c);
      }
      else
      {
        LOG_E("TEMP", "DS18B20 read failed (missing/unpowered or bad CRC)");
      }
      break;
    }
    case CMD_FORCE_SAFE:
      force_safe_all();
      hv_activity();
      Proto_ClearArm();
      /* Announce only now, with the rail actually down. Emitting !SAFE at the
       * point the command was *posted* told the GUI it was safe to handle the
       * harness while the hardware had not been touched yet (FW-08). */
      Proto_EvtHv(0);
      Proto_EvtSafe();
      if (c->b == CMD_SAFE_ANNOUNCE_FIXTURE)
      {
        /* Ordering !HV 0 -> !SAFE -> !FIXTURE is the published contract
         * (GUI_development_brief.md 3.2.1); keep it. */
        Proto_EvtFixture((ProtoFixture_t)c->a);
      }
      LOG_I("SEQ", "forced safe");
      break;
    case CMD_CONT_RUN:
      run_continuity_all((uint8_t)c->a);
      break;
    case CMD_RES_RUN:
      run_resistance_all();
      break;
    case CMD_INSUL_RUN:
      run_insulation_all();
      break;
    case CMD_MANUAL_SWEEP:
      run_manual_sweep(c->a);
      break;
    default:
      break;
  }
  osMutexRelease(s_hwmtx);
}

/**
  * @brief  Continuity over the whole netlist, or a full discovery scan.
  * @note   Streams one !CONT per pair as it goes rather than accumulating -
  *         a discovery scan is 65,536 points and the operator should see
  *         progress, not a frozen screen.
  * @param  discover : [in] 0 = verify the loaded netlist, 1 = scan everything.
  * @retval None
  */
static void run_continuity_all(uint8_t discover)
{
  ContinuityResult_t r;
  uint16_t i, n, hi, lo;
  uint16_t pass = 0U, fail = 0U;
  uint16_t bus_err = 0U;

  /* Do NOT clear the abort flag here. proto_post_run() clears it before the
   * command is queued, which is the only point where clearing is correct; a
   * second clear at run start silently swallows an abort that arrived in
   * between - and comms runs above the sequencer, so it lands there easily
   * (FW-09). Proto_EvtDone() clears it again on the way out. */
  Proto_EvtState("running");

  if (discover != 0U)
  {
    /* Discovery: every HI against every LO. Report only what is found - a
     * complete 65,536-line dump would swamp the link and the operator. */
    for (hi = 1U; hi <= 256U; hi++)
    {
      for (lo = 1U; lo <= 256U; lo++)
      {
        if (Continuity_TestPair(hi, lo, &r) != HAL_OK)
        {
          bus_err++;        /* a bus error is NOT "no connection": count it */
        }
        else if (r.verdict == TEST_PASS)
        {
          Proto_EvtCont(hi, lo, "pass");
          pass++;
        }
      }
      Proto_EvtProgress(hi, 256U);
      if (s_fault != 0U || Proto_AbortRequested() != 0U) { break; }
    }
    if (bus_err != 0U)
    {
      /* The scan is incomplete: say so, and count the errors as failures so the
       * run cannot read as a clean pass. */
      Proto_EvtFault("F01", "bus error during scan: result incomplete");
      fail = bus_err;
    }
  }
  else
  {
    n = Proto_NetlistCount();
    for (i = 0U; i < n; i++)
    {
      if (Proto_NetlistGet(i, &hi, &lo) != 0) { continue; }
      if (Continuity_TestPair(hi, lo, &r) != HAL_OK)
      {
        /* Reported as open (the pair is NOT verified) but flagged as a bus error,
         * not as a missing wire. */
        Proto_EvtCont(hi, lo, "open");
        Proto_EvtFault("F01", "bus error: pair not verified");
        fail++;
      }
      else if (r.verdict == TEST_PASS)
      {
        Proto_EvtCont(hi, lo, "pass");
        pass++;
      }
      else
      {
        Proto_EvtCont(hi, lo, "open");
        Proto_EvtFault("F06", "continuity open");
        fail++;
      }
      Proto_EvtProgress((uint16_t)(i + 1U), n);
      if (s_fault != 0U || Proto_AbortRequested() != 0U) { break; }
    }
  }

  Proto_EvtState("idle");
  Proto_EvtDone("cont", pass, fail);
}

/**
  * @brief  One HS pin against all 256 LS - a bounded version of
  *         run_continuity_all(discover=1)'s inner loop, for `MANUAL SWEEP`
  *         (GUI-06, 2026-08-21). Reports only matches found, same reasoning
  *         as full discovery: a 256-line dump of everything NOT found would
  *         swamp the link for no reason.
  * @param  hi : [in] the one HS pin to sweep, 1..256 (already range-checked
  *                    by proto.c).
  * @retval None
  */
static void run_manual_sweep(uint16_t hi)
{
  ContinuityResult_t r;
  uint16_t lo;
  uint16_t found = 0U;

  Proto_EvtState("running");
  for (lo = 1U; lo <= 256U; lo++)
  {
    if (Continuity_TestPair(hi, lo, &r) == HAL_OK && r.verdict == TEST_PASS)
    {
      Proto_EvtCont(hi, lo, "pass");
      found++;
    }
    if ((lo % 16U) == 0U) { Proto_EvtProgress(lo, 256U); }
    if (s_fault != 0U || Proto_AbortRequested() != 0U) { break; }
  }
  Proto_EvtState("idle");
  Proto_EvtDone("sweep", found, 0U);
}

/**
  * @brief  Resistance over the loaded netlist.
  * @note   Kelvin_MeasurePair (FW-02) reads HI_SENSE/LO_SENSE on the Matrix
  *         Card's ADS124S08, auto-ranging the PGA and subtracting a
  *         zero-current baseline per point. A bus/driver error (not a real
  *         over-limit reading) still reports fail_high here rather than a
  *         number computed from a failed conversion.
  * @retval None
  */

#define RES_NEG_TOL_MOHM   100L   /* a reading below -100 mOhm is not noise */

static void run_resistance_all(void)
{
  KelvinResult_t r;
  uint16_t i, n, hi, lo;
  uint16_t pass = 0U, fail = 0U;
  int32_t  limit = Proto_LimitRMaxMohm();

  /* Do NOT clear the abort flag here. proto_post_run() clears it before the
   * command is queued, which is the only point where clearing is correct; a
   * second clear at run start silently swallows an abort that arrived in
   * between - and comms runs above the sequencer, so it lands there easily
   * (FW-09). Proto_EvtDone() clears it again on the way out. */
  Proto_EvtState("running");
  n = Proto_NetlistCount();

  for (i = 0U; i < n; i++)
  {
    if (Proto_NetlistGet(i, &hi, &lo) != 0) { continue; }

    if (Kelvin_MeasurePair(hi, lo, &r) != HAL_OK)
    {
      Proto_EvtRes(hi, lo, 0, "fail_high");
      Proto_EvtFault("F08", "resistance path unavailable");
      fail++;
    }
    else
    {
      int32_t mohm;
      const char *v;
      if (RunLogic_ResMohmToWire(r.resistance_ohm, &mohm) != 0)
      {
        v = "fail_high";                    /* not a number: never a pass */
      }
      else if (mohm < -RES_NEG_TOL_MOHM)
      {
        v = "fail_low";                     /* negative: offset or wiring error */
        Proto_EvtFault("F09", "resistance negative: check wiring and calibration");
      }
      else
      {
        v = (mohm <= limit) ? "pass" : "fail_high";
      }
      Proto_EvtRes(hi, lo, mohm, v);
      if (v[0] == 'p') { pass++; } else { fail++; }
    }
    Proto_EvtProgress((uint16_t)(i + 1U), n);
    if (s_fault != 0U || Proto_AbortRequested() != 0U) { break; }
  }

  Proto_EvtState("idle");
  Proto_EvtDone("res", pass, fail);
}

/* Netlist accessor handed to the pure return-relay planner (run_logic.c). */
static int netlist_get(uint16_t i, uint16_t *hi, uint16_t *lo) { return Proto_NetlistGet(i, hi, lo); }

/**
  * @brief  Insulation over the loaded netlist.
  * @note   Refuses to run unless HV was armed, and always drops the rail and
  *         clears the arm on the way out - arming must never survive a run.
  * @retval None
  */
static void run_insulation_all(void)
{
  InsulationResult_t r;
  uint16_t i, n, hi, lo;
  uint16_t pass = 0U, fail = 0U;
  HAL_StatusTypeDef st_net;

  if (Proto_HvArmed() == 0U)
  {
    Proto_EvtFault("F05", "HV not armed");
    Proto_EvtDone("insul", 0U, 0U);
    return;
  }

  /* Do NOT clear the abort flag here. proto_post_run() clears it before the
   * command is queued, which is the only point where clearing is correct; a
   * second clear at run start silently swallows an abort that arrived in
   * between - and comms runs above the sequencer, so it lands there easily
   * (FW-09). Proto_EvtDone() clears it again on the way out. */
  n = Proto_NetlistCount();

  /* Refuse up front if any HS pin is beyond the HV cards fitted (each card has
   * HV_PINS_PER_SIDE relays): reporting that as a per-net measurement failure
   * would be a spurious fault on most of a 256-line netlist. */
  for (i = 0U; i < n; i++)
  {
    if (Proto_NetlistGet(i, &hi, &lo) != 0) { continue; }
    if (hi < 1U || lo < 1U || (hi - 1U) / HV_PINS_PER_SIDE >= (uint16_t)BOARD_HV_COUNT)
    {
      Proto_EvtFault("F05", "netlist pin outside fitted HV cards");
      Proto_ClearArm();
      Proto_EvtDone("insul", 0U, 0U);
      return;
    }
  }
  /* Prove the HV path before trusting a single reading: a wrong DAC/ADC
   * chip-select or a dead card enable would otherwise read ~0 V = PASS. */
  for (i = 0U; i < (uint16_t)BOARD_HV_COUNT; i++)
  {
    float v_idle = 0.0f, v_hv = 0.0f;
    if (Insulation_HvSelfTest((uint8_t)i, &v_idle, &v_hv) != HAL_OK)
    {
      LOG_E("INS", "b%u HV self-test FAILED idle=%dmV rail=%dmV", (unsigned)i,
            (int)(v_idle * 1000.0f), (int)(v_hv * 1000.0f));
      Proto_EvtFault("F03", "HV path self-test failed");
      Safety_SignalFault("HV self-test failed");
      force_safe_all();
      hv_activity();
      Proto_ClearArm();
      Proto_EvtHv(0);
      Proto_EvtSafe();
      Proto_EvtDone("insul", 0U, 0U);
      return;
    }
  }
  hv_activity();
  Proto_EvtState("running");

  for (i = 0U; i < n; i++)
  {
    uint8_t  board, local;
    uint64_t rmask;
    if (Proto_NetlistGet(i, &hi, &lo) != 0) { continue; }

    board = (uint8_t)((hi - 1U) / HV_PINS_PER_SIDE);
    local = (uint8_t)((hi - 1U) % HV_PINS_PER_SIDE + 1U);
    rmask = RunLogic_ReturnMask(netlist_get, n, hi, lo, board, HV_PINS_PER_SIDE);

    r.hw_fault = INS_HW_NONE;
    s_hv_active = 1U;
    st_net = Insulation_TestNet(board, local, rmask, INSULATION_RUN_FRACTION, &r);
    s_hv_active = 0U;
    hv_activity();

    if (r.hw_fault != INS_HW_NONE)
    {
      /* The HV path itself misbehaved (relay bus, DAC/ADC, rail out of
       * tolerance, rail would not discharge). That is not a harness failure and
       * no further net can be trusted: report it, latch the fault, stop. */
      static const char *const why[] = {
        "none", "HV relay bus error", "HV DAC/ADC error",
        "HV rail out of tolerance", "HV rail did not discharge" };
      Proto_EvtInsul(hi, 0, "fail");
      Proto_EvtFault((r.hw_fault == INS_HW_BUS) ? "F01" :
                     (r.hw_fault == INS_HW_SPI) ? "F02" : "F03",
                     why[(r.hw_fault <= INS_HW_DISCHARGE) ? r.hw_fault : 0U]);
      Safety_SignalFault(why[(r.hw_fault <= INS_HW_DISCHARGE) ? r.hw_fault : 0U]);
      fail++;
      break;
    }
    if (st_net != HAL_OK)
    {
      Proto_EvtInsul(hi, 0, "fail");
      Proto_EvtFault("F04", "insulation measurement failed");
      fail++;
    }
    else
    {
      const char *v = (r.verdict == TEST_PASS) ? "pass" : "fail";
      /* insulation_mohm is the header's megohm estimate; the protocol
       * carries milliohms, so scale by 1e9. */
      Proto_EvtInsul(hi, RunLogic_InsulMohmToWire(r.insulation_mohm), v);
      if (r.verdict == TEST_PASS) { pass++; }
      else { Proto_EvtFault("F04", "insulation low"); fail++; }
    }
    Proto_EvtProgress((uint16_t)(i + 1U), n);
    if (s_fault != 0U || Proto_AbortRequested() != 0U) { break; }
  }

  /* Always leave HV down and disarmed. */
  force_safe_all();
  hv_activity();
  Proto_ClearArm();
  Proto_EvtHv(0);
  Proto_EvtSafe();
  Proto_EvtState("idle");
  Proto_EvtDone("insul", pass, fail);
}

/**
  * @brief  Sequencer thread: run queued test commands one at a time.
  * @note   Blocks on the command queue and hands each command to run_command(),
  *         which serialises hardware access. Runs forever.
  * @param  arg : [in] unused FreeRTOS thread argument.
  * @retval None (does not return).
  */
static void SequencerTask(void *arg)
{
  TestCmd_t cmd;
  (void)arg;
  LOG_I("SEQ", "task up");
  for (;;)
  {
    if (osMessageQueueGet(s_cmdq, &cmd, NULL, osWaitForever) == osOK)
    {
      run_command(&cmd);
    }
  }
}

/* ---- comms (Nucleo bring-up console over the VCP) ------------------------- */

/**
  * @brief  Build a TestCmd_t from loose fields and post it to the queue.
  * @note   Convenience helper for the bring-up console key handler.
  * @param  t     : [in] command type.
  * @param  a     : [in] first pin / primary argument.
  * @param  b     : [in] second pin / secondary argument.
  * @param  board : [in] HV board index (insulation only).
  * @param  vf    : [in] HV fraction (insulation only).
  * @retval None
  */
/* post_simple() removed with the single-keystroke console - the protocol layer
 * builds and posts commands itself (see Core/Src/app/proto.c). */

/**
  * @brief  Console RX complete: hand the byte to tComms and re-arm.
  * @note   Runs in the USART2 ISR at priority 5, the most urgent level allowed
  *         to call the FreeRTOS FromISR API. Re-arming here is what keeps the
  *         receiver alive; miss it once and the link goes deaf.
  * @param  huart : [in] UART reporting the completion.
  * @retval None
  */
void HAL_UART_RxCpltCallback(UART_HandleTypeDef *huart)
{
  if (huart == s_console)
  {
    /* Drop-if-full rather than block: an ISR must not wait, and a full queue
     * means tComms is wedged, which losing one byte will not make worse. */
    (void)osMessageQueuePut(s_rxq, &s_rx_byte, 0U, 0U);
    (void)HAL_UART_Receive_IT(huart, &s_rx_byte, 1U);
  }
}

/**
  * @brief  Console UART error: clear the condition and re-arm RX.
  * @note   Overrun is the expected one - the GUI can send while the line is
  *         busy. HAL aborts the pending receive on any error, so without this
  *         re-arm a single overrun would silently deafen the instrument for
  *         good.
  * @param  huart : [in] UART reporting the error.
  * @retval None
  */
void HAL_UART_ErrorCallback(UART_HandleTypeDef *huart)
{
  if (huart == s_console)
  {
    __HAL_UART_CLEAR_OREFLAG(huart);
    __HAL_UART_CLEAR_NEFLAG(huart);
    __HAL_UART_CLEAR_FEFLAG(huart);
    __HAL_UART_CLEAR_PEFLAG(huart);
    (void)HAL_UART_Receive_IT(huart, &s_rx_byte, 1U);
  }
}

/**
  * @brief  Comms thread: feed received bytes to the protocol parser.
  * @note   Blocks on the RX queue, so it consumes nothing until a byte arrives -
  *         which is why it can afford to sit above the sequencer in priority.
  *         That placement is the point: a command must be parsed and answered
  *         while a run is executing, not after it (FW-07). Runs forever.
  * @param  arg : [in] unused FreeRTOS thread argument.
  * @retval None (does not return).
  */
static void CommsTask(void *arg)
{
  uint8_t ch;
  uint32_t last_beat;
  (void)arg;

  Proto_Init(s_console);

  if (s_console != NULL)
  {
    (void)HAL_UART_Receive_IT(s_console, &s_rx_byte, 1U);
  }

  LOG_I("COM", "proto ready (see GUI_development_brief.md)");
  Proto_EvtState("idle");
  Proto_EvtFixture(PROTO_FIXTURE_NONE);

  last_beat = osKernelGetTickCount();

  for (;;)
  {
    /* Timed wait rather than osWaitForever: this task also has to emit the
     * liveness heartbeat, and it cannot do that while parked on the queue. A
     * byte still wakes it immediately, so command latency is unchanged. */
    if (osMessageQueueGet(s_rxq, &ch, NULL, PROTO_HEARTBEAT_MS) == osOK)
    {
      Proto_RxByte(ch);
    }

    /* Measured against the clock, not against queue timeouts: a steady trickle
     * of received bytes would otherwise keep resetting the wait and starve the
     * heartbeat - which is precisely when the GUI is still waiting to hear
     * something back. configTICK_RATE_HZ is 1000, so ticks are milliseconds. */
    if ((osKernelGetTickCount() - last_beat) >= PROTO_HEARTBEAT_MS)
    {
      last_beat = osKernelGetTickCount();
      Proto_EvtHeartbeat();
    }
  }
}

/* ---- public -------------------------------------------------------------- */

/**
  * @brief  Post a test command to the sequencer queue (non-blocking).
  * @param  cmd : [in] command to enqueue; must be non-NULL.
  * @retval 0  command enqueued.
  * @retval -1 @p cmd is NULL or the queue does not exist.
  * @retval 1  queue full (command dropped).
  */
int Tasks_PostCommand(const TestCmd_t *cmd)
{
  if (cmd == NULL || s_cmdq == NULL)
  {
    return -1;
  }
  return (osMessageQueuePut(s_cmdq, cmd, 0U, 0U) == osOK) ? 0 : 1;
}

/**
  * @brief  Write a string straight to the console UART, synchronously.
  * @note   Bypasses the log queue so a boot banner / failure message appears
  *         even if tasks or the heap failed to come up, as long as the UART
  *         itself is alive. No-op if the console or @p s is NULL.
  *         Callers must prefix '#': every instrument -> GUI line has to carry a
  *         marker (GUI_development_brief.md 3.1), and a bare banner is a parse
  *         error at the other end. No leading newline either, for the same
  *         reason - an empty line is not a valid frame.
  * @param  s : [in] NUL-terminated string to transmit.
  * @retval None
  */
static void console_puts(const char *s)
{
  if (s_console != NULL && s != NULL)
  {
    (void)HAL_UART_Transmit(s_console, (uint8_t *)s, (uint16_t)strlen(s), 50U);
  }
}

/**
  * @brief  Bring up the console, logger, IPC objects and all RTOS threads.
  * @note   Brings up the VCP first so boot progress is always visible, then
  *         creates the hardware mutex, command queue and the four threads
  *         (logger, safety, sequencer, comms). Allocation failures are reported
  *         synchronously on the console (heap too small). Call once, after the
  *         scheduler primitives are available.
  * @retval None
  */
void Tasks_Init(void)
{
  s_console = Log_HwInit_Console();   /* USART2 -> MCP2221A USB-UART (Nucleo: ST-LINK VCP) */
  console_puts("#[boot] HT_MK1 console up @115200\r\n");
  if (Log_Init(s_console) != HAL_OK)
  {
    console_puts("#[boot] LOG init FAILED\r\n");
  }

  s_hwmtx = osMutexNew(NULL);
  s_cmdq  = osMessageQueueNew(8U, sizeof(TestCmd_t), NULL);
  /* One command line's worth of headroom, so a burst arriving while tComms is
   * mid-reply is buffered rather than dropped. */
  s_rxq   = osMessageQueueNew(PROTO_RX_MAX + 8U, sizeof(uint8_t), NULL);
  if (s_cmdq == NULL || s_rxq == NULL)
  {
    console_puts("#[boot] queue alloc FAILED (heap?)\r\n");
  }

  s_logger = osThreadNew(Log_Task,      NULL, &s_attr_logger);
  s_safety = osThreadNew(SafetyTask,    NULL, &s_attr_safety);
  s_seq    = osThreadNew(SequencerTask, NULL, &s_attr_seq);
  s_comms  = osThreadNew(CommsTask,     NULL, &s_attr_comms);

  /* Loud, synchronous report if any thread failed to allocate (heap too small). */
  if (s_logger == NULL || s_safety == NULL || s_seq == NULL || s_comms == NULL)
  {
    console_puts("#[boot] TASK CREATE FAILED - increase configTOTAL_HEAP_SIZE\r\n");
  }

#if (HT_ENABLE_ADS1232 != 0)
  s_ads1232 = osThreadNew(Ads1232BenchTask, NULL, &s_attr_ads1232);
  if (s_ads1232 == NULL)
  {
    console_puts("#[boot] ADS1232 bench task alloc FAILED\r\n");
  }
#endif

  LOG_I("SYS", "tasks started (hv boards=%u)", (unsigned)BOARD_HV_COUNT);
}
